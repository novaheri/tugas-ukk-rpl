<?php
include "koneksi.php";

if (isset($_POST['simpan'])) {

    $nama_kategori = $_POST['nama_kategori'];
    $kode_kategori = $_POST['kode_kategori'];
    $keterangan = $_POST['keterangan'];
    $status = $_POST['status'];

    mysqli_query($conn, "INSERT INTO tb_kategori
        (nama_kategori, kode_kategori, keterangan, status)
        VALUES
        ('$nama_kategori', '$kode_kategori', '$keterangan', '$status')");

    header("Location: tampil.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Kategori</title>
</head>
<body>

<h2>Tambah Data Kategori</h2>

<form method="POST">

    Nama Kategori:
    <input type="text" name="nama_kategori" required>
    <br><br>

    Kode Kategori:
    <input type="text" name="kode_kategori" required>
    <br><br>

    Keterangan:
    <input type="text" name="keterangan" required>
    <br><br>

    Status:
    <select name="status" required>
        <option value="Aktif">Aktif</option>
        <option value="Tidak Aktif">Tidak Aktif</option>
    </select>
    <br><br>

    <button type="submit" name="simpan">Simpan</button>

</form>

<br>

<a href="tampil.php">Kembali</a>

</body>
</html>