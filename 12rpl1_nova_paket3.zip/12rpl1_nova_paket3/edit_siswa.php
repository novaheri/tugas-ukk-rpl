<?php

include "koneksi_siswa.php";

// ==========================
// CEK ID
// ==========================

if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("ID siswa tidak ditemukan.");
}

$id_siswa = $_GET['id'];


// ==========================
// AMBIL DATA SISWA
// ==========================

$query = "SELECT * FROM tb_siswa WHERE id_siswa = '$id_siswa'";

$result = mysqli_query($conn, $query);

if (!$result) {
    die("Query gagal: " . mysqli_error($conn));
}

if (mysqli_num_rows($result) == 0) {
    die("Data siswa tidak ditemukan.");
}

$data = mysqli_fetch_assoc($result);


// ==========================
// PROSES UPDATE
// ==========================

if (isset($_POST['update'])) {

    $nis = $_POST['nis'];
    $nama_siswa = $_POST['nama_siswa'];
    $kelas = $_POST['kelas'];
    $alamat = $_POST['alamat'];

    $query_update = "UPDATE tb_siswa SET
        nis = '$nis',
        nama_siswa = '$nama_siswa',
        kelas = '$kelas',
        alamat = '$alamat'
        WHERE id_siswa = '$id_siswa'
    ";

    if (mysqli_query($conn, $query_update)) {

        echo "<script>
                alert('Data siswa berhasil diubah!');
                window.location='tampil_siswa.php';
              </script>";

        exit;

    } else {

        die("Gagal mengubah data: " . mysqli_error($conn));

    }
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Edit Data Siswa</title>

</head>

<body>

<h2>Edit Data Siswa</h2>

<form method="POST">

    <label>NIS</label>
    <br>

    <input
        type="text"
        name="nis"
        value="<?= htmlspecialchars($data['nis']); ?>"
        required
    >

    <br><br>


    <label>Nama Siswa</label>
    <br>

    <input
        type="text"
        name="nama_siswa"
        value="<?= htmlspecialchars($data['nama_siswa']); ?>"
        required
    >

    <br><br>


    <label>Kelas</label>
    <br>

    <input
        type="text"
        name="kelas"
        value="<?= htmlspecialchars($data['kelas']); ?>"
        required
    >

    <br><br>


    <label>Alamat</label>
    <br>

    <textarea
        name="alamat"
        rows="5"
        required
    ><?= htmlspecialchars($data['alamat']); ?></textarea>

    <br><br>


    <button type="submit" name="update">
        Simpan Perubahan
    </button>

    <a href="tampil_siswa.php">
        Kembali
    </a>

</form>

</body>

</html>
```
