<?php
include "koneksi.php";

if (isset($_POST['simpan'])) {

    $nama = $_POST['nama_siswa'];
    $nis = $_POST['nis'];
    $kelas = $_POST['kelas'];
    $alamat = $_POST['alamat'];

    $query = "INSERT INTO tb_siswa
              (nama_siswa, nis, kelas, alamat)
              VALUES
              ('$nama', '$nis', '$kelas', '$alamat')";

    if (mysqli_query($conn, $query)) {
        header("Location: tampil_siswa.php");
        exit;
    } else {
        echo "Data gagal disimpan: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Siswa</title>
</head>
<body>

<h2>Tambah Data Siswa</h2>

<form method="POST">

    Nama Siswa:
    <input type="text" name="nama_siswa" required>
    <br><br>

    NIS:
    <input type="text" name="nis" required>
    <br><br>

    Kelas:
    <input type="text" name="kelas" required>
    <br><br>

    Alamat:
    <textarea name="alamat" required></textarea>
    <br><br>

    <button type="submit" name="simpan">Simpan</button>

</form>

<br>

<a href="tampil_siswa.php">Kembali</a>

</body>
</html>