<?php

$conn = mysqli_connect("localhost", "root", "", "12rpl_nova_paket3");

// Alias untuk halaman lama yang masih memakai nama $koneksi.
$koneksi = $conn;

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

?>
