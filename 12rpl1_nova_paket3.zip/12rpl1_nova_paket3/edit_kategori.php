<?php
include "koneksi.php";

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: tampil_kategori.php");
    exit;
}

$id = $_GET['id'];

$stmt = mysqli_prepare($conn, "SELECT * FROM tb_kategori WHERE id_kategori = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($result);

if (!$row) {
    header("Location: tampil_kategori.php");
    exit;
}

if (isset($_POST['update'])) {

    $nama_kategori = $_POST['nama_kategori'];
    $kode_kategori = $_POST['kode_kategori'];
    $keterangan = $_POST['keterangan'];
    $status = $_POST['status'];

    $update_stmt = mysqli_prepare($conn, "UPDATE tb_kategori SET
                  nama_kategori = ?,
                  kode_kategori = ?,
                  keterangan = ?,
                  status = ?
                  WHERE id_kategori = ?");

    mysqli_stmt_bind_param($update_stmt, "ssssi", $nama_kategori, $kode_kategori, $keterangan, $status, $id);

    if (mysqli_stmt_execute($update_stmt)) {
        header("Location: tampil_kategori.php");
        exit;
    } else {
        echo "Data gagal diubah: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Kategori</title>
</head>
<body>

<h2>Edit Data Kategori</h2>

<form method="POST">

    Nama Kategori:
    <input type="text" name="nama_kategori"
           value="<?php echo htmlspecialchars($row['nama_kategori'], ENT_QUOTES, 'UTF-8'); ?>" required>
    <br><br>

    Kode Kategori:
    <input type="text" name="kode_kategori"
           value="<?php echo htmlspecialchars($row['kode_kategori'], ENT_QUOTES, 'UTF-8'); ?>" required>
    <br><br>

    Keterangan:
    <textarea name="keterangan" required><?php echo htmlspecialchars($row['keterangan'], ENT_QUOTES, 'UTF-8'); ?></textarea>
    <br><br>

    Status:
    <select name="status" required>
        <option value="Aktif"
        <?php if ($row['status'] == 'Aktif') echo 'selected'; ?>>
        Aktif
        </option>

        <option value="Tidak Aktif"
        <?php if ($row['status'] == 'Tidak Aktif') echo 'selected'; ?>>
        Tidak Aktif
        </option>
    </select>
    <br><br>

    <button type="submit" name="update">Update</button>

</form>

<br>

<a href="tampil_kategori.php">Kembali</a>

</body>
</html>