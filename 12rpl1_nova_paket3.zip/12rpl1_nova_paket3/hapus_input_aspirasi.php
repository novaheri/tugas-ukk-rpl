<?php
include "koneksi.php";

$id = $_GET['id'];

$sql = "DELETE FROM tb_input_aspirasi WHERE id_input='$id'";

if (mysqli_query($conn, $sql)) {
    header("Location: tampil_input_aspirasi.php");
    exit;
} else {
    echo "Gagal menghapus: " . mysqli_error($conn);
}
?>