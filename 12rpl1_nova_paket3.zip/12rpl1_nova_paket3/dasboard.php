<?php
include "koneksi_siswa.php";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Pengaduan Sarana</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f2f2f2;
            margin: 0;
        }

        .header {
            background: #6a1b9a;
            color: white;
            padding: 25px;
            text-align: center;
        }

        .container {
            width: 90%;
            margin: 30px auto;
        }

        .menu {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }

        .card {
            background: white;
            padding: 25px;
            text-align: center;
            border-radius: 10px;
            box-shadow: 0 3px 8px #ccc;
        }

        .card h3 {
            color: #6a1b9a;
        }

        .card a {
            display: inline-block;
            background: #6a1b9a;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
        }

        .card a:hover {
            background: #4a148c;
        }

        footer {
            text-align: center;
            margin-top: 40px;
            padding: 15px;
        }
    </style>
</head>

<body>

<div class="header">
    <h1>DASHBOARD</h1>
    <p>Sistem Pengaduan Sarana Sekolah</p>
</div>

<div class="container">

    <div class="menu">

        <div class="card">
            <h3>Data Siswa</h3>
            <p>Kelola data siswa</p>
            <a href="tampil_siswa.php">Buka</a>
        </div>

        <div class="card">
            <h3>Data Admin</h3>
            <p>Kelola data admin</p>
            <a href="tampil_admin.php">Buka</a>
        </div>

        <div class="card">
            <h3>Data Kategori</h3>
            <p>Kelola kategori pengaduan</p>
            <a href="tampil_kategori.php">Buka</a>
        </div>

        <div class="card">
            <h3>Data Aspirasi</h3>
            <p>Kelola data aspirasi</p>
            <a href="tampil_aspirasi.php">Buka</a>
        </div>

        <div class="card">
            <h3>Input Aspirasi</h3>
            <p>Kelola input aspirasi</p>
            <a href="tampil_input_aspirasi.php">Buka</a>
        </div>

    </div>

</div>

<footer>
    <p>Nova Herawati</p>
</footer>

</body>
</html>