
<?php
include "koneksi.php";

// Mengambil ID aspirasi dari URL
$id = $_GET['id_input'] ?? null;

if ($id === null) {
    die("ID aspirasi tidak ditemukan. Silakan klik tombol Edit.");
}

// Mengambil data aspirasi berdasarkan ID
$stmt = mysqli_prepare($conn, "SELECT * FROM tb_input_aspirasi WHERE id_input = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

$data = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($data);

if (!$row) {
    die("Data aspirasi tidak ditemukan.");
}

// Proses update data
if (isset($_POST['update'])) {

    $id_siswa = $_POST['id_siswa'];
    $id_kategori = $_POST['id_kategori'];
    $isi_aspirasi = $_POST['isi_aspirasi'];
    $tanggal = $_POST['tanggal'];

    $sql = "UPDATE tb_input_aspirasi SET
            id_siswa = ?,
            id_kategori = ?,
            isi_aspirasi = ?,
            tanggal = ?
            WHERE id_input = ?";

    $stmt = mysqli_prepare($conn, $sql);

    mysqli_stmt_bind_param(
        $stmt,
        "iissi",
        $id_siswa,
        $id_kategori,
        $isi_aspirasi,
        $tanggal,
        $id
    );

    if (mysqli_stmt_execute($stmt)) {
        header("Location: tampil_input_aspirasi.php");
        exit;
    } else {
        echo "Gagal mengubah: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Aspirasi</title>
</head>
<body>

<h2>EDIT ASPIRASI</h2>

<form method="POST">

    ID Siswa:<br>
    <input type="number" name="id_siswa"
           value="<?php echo htmlspecialchars($row['id_siswa']); ?>"
           required>
    <br><br>

    ID Kategori:<br>
    <input type="number" name="id_kategori"
           value="<?php echo htmlspecialchars($row['id_kategori']); ?>"
           required>
    <br><br>

    Isi Aspirasi:<br>
    <textarea name="isi_aspirasi" required><?php
        echo htmlspecialchars($row['isi_aspirasi']);
    ?></textarea>
    <br><br>

    Tanggal:<br>
    <input type="date" name="tanggal"
           value="<?php echo htmlspecialchars($row['tanggal']); ?>"
           required>
    <br><br>

    <button type="submit" name="update">Update</button>

</form>

</body>
</html>

