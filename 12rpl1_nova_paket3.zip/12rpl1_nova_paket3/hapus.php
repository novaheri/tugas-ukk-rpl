<?php
include "koneksi.php";

$id = $_GET['id'];

mysqli_query($conn, "DELETE FROM tb_kategori WHERE id_kategori='$id'");

header("Location: tampil.php");
exit;