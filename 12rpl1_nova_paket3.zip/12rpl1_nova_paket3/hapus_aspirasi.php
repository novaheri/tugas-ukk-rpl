<?php
include "koneksi.php";

$id = $_GET['id'];

$query = "DELETE FROM tb_aspirasi WHERE id_aspirasi='$id'";

if (mysqli_query($conn, $query)) {
    header("Location: tampil_aspirasi.php");
    exit;
} else {
    echo "Data gagal dihapus: " . mysqli_error($conn);
}
?>