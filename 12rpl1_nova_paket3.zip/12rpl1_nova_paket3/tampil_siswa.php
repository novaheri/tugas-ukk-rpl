<?php
include "koneksi_siswa.php";

$data = mysqli_query($conn, "SELECT * FROM tb_siswa");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Siswa</title>
</head>
<body>

<h2>DATA SISWA</h2>

<a href="tambah_siswa.php">+ Tambah Siswa</a>

<br><br>

<table border="1" cellpadding="8">
    <tr>
        <th>ID Siswa</th>
        <th>Nama Siswa</th>
        <th>NIS</th>
        <th>Kelas</th>
        <th>Alamat</th>
        <th>Aksi</th>
    </tr>

    <?php while ($row = mysqli_fetch_assoc($data)) { ?>
    <tr>
        <td><?php echo $row['id_siswa']; ?></td>
        <td><?php echo $row['nama_siswa']; ?></td>
        <td><?php echo $row['nis']; ?></td>
        <td><?php echo $row['kelas']; ?></td>
        <td><?php echo $row['alamat']; ?></td>
        <td>
            <a href="edit_siswa.php?id=<?php echo $row['id_siswa']; ?>">Edit</a>
            |
            <a href="hapus_siswa.php?id=<?php echo $row['id_siswa']; ?>"
               onclick="return confirm('Yakin ingin menghapus data ini?')">
               Hapus
            </a>
        </td>
    </tr>
    <?php } ?>

</table>

</body>
</html>