<?php

$conn = mysqli_connect(
    "localhost",
    "root",
    "",
    "12rpl_nova_paket3"
);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
