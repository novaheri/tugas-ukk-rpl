<?php
session_start();
include "koneksi.php";

if (isset($_POST['login'])) {

    $nis = $_POST['nis'];
    $nama = $_POST['nama'];

    $query = "SELECT * FROM tb_siswa 
        WHERE nis='$nis' AND nama_siswa='$nama'";

 $data = mysqli_query($conn, $query);


    if (mysqli_num_rows($data) > 0) {

       $_SESSION['login'] = true;
        $_SESSION['nama'] = $nama;
       

        header("Location: dashboard_siswa.php");
        exit;

    } else {
        $error = "NIS atau nama siswa salah!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login Siswa</title>
</head>
<body>

<h2>LOGIN SISWA</h2>

<?php
if (isset($error)) {
    echo "<p>$error</p>";
}
?>

<form method="POST">

    NIS:
    <br>
    <input type="text" name="nis" required>

    <br><br>

    Nama Siswa:
    <br>
    <input type="text" name="nama" required>

    <br><br>

    <button type="submit" name="login">Login</button>

</form>

</body>
</html>