<?php
include "koneksi.php";

if (isset($_POST['simpan'])) {

    $id_siswa = $_POST['id_siswa'];
    $id_kategori = $_POST['id_kategori'];
    $isi_aspirasi = $_POST['isi_aspirasi'];
    $tanggal = $_POST['tanggal'];

    $sql = "INSERT INTO tb_input_aspirasi
            (id_siswa, id_kategori, isi_aspirasi, tanggal)
            VALUES
            ('$id_siswa', '$id_kategori', '$isi_aspirasi', '$tanggal')";

    if (mysqli_query($conn, $sql)) {
        header("Location: tampil_input_aspirasi.php");
        exit;
    } else {
        echo "Gagal menyimpan: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Aspirasi</title>
</head>
<body>

<h2>INPUT ASPIRASI</h2>

<form method="POST">

    ID Siswa:<br>
    <input type="number" name="id_siswa" required>
    <br><br>

    ID Kategori:<br>
    <input type="number" name="id_kategori" required>
    <br><br>

    Isi Aspirasi:<br>
    <textarea name="isi_aspirasi" required></textarea>
    <br><br>

    Tanggal:<br>
    <input type="date" name="tanggal" required>
    <br><br>

    <button type="submit" name="simpan">Simpan</button>

</form>

</body>
</html>