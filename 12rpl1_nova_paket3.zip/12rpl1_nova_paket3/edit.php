<?php
include "koneksi.php";

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id) {
    $id = filter_input(INPUT_GET, 'id_kategori', FILTER_VALIDATE_INT);
}

if (!$id) {
    header("Location: tampil_kategori.php");
    exit;

}

$data = mysqli_query($conn, "SELECT * FROM tb_kategori WHERE id_kategori=$id");
$row = mysqli_fetch_assoc($data);

if (!$row) {
    die("Data kategori tidak ditemukan.");
}

if (isset($_POST['update'])) {

    $nama_kategori = $_POST['nama_kategori'];
    $kode_kategori = $_POST['kode_kategori'];
    $keterangan = $_POST['keterangan'];
    $status = $_POST['status'];

    mysqli_query($conn, "UPDATE tb_kategori SET
        nama_kategori='$nama_kategori',
        kode_kategori='$kode_kategori',
        keterangan='$keterangan',
        status='$status'
        WHERE id_kategori=$id");

    header("Location: tampil.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Kategori</title>
</head>
<body>

<h2>Edit Data Kategori</h2>

<form method="POST">

    Nama Kategori:
    <input type="text" name="nama_kategori"
           value="<?php echo htmlspecialchars($row['nama_kategori']); ?>" required>
    <br><br>

    Kode Kategori:
    <input type="text" name="kode_kategori"
           value="<?php echo htmlspecialchars($row['kode_kategori']); ?>" required>
    <br><br>

    Keterangan:
    <input type="text" name="keterangan"
           value="<?php echo htmlspecialchars($row['keterangan']); ?>" required>
    <br><br>

    Status:
    <select name="status" required>
        <option value="Aktif"
        <?php if ($row['status'] == 'Aktif') echo 'selected'; ?>>
            Aktif
        </option>

        <option value="Tidak Aktif"
        <?php if ($row['status'] == 'Tidak Aktif') echo 'selected'; ?>>
            Tidak Aktif
        </option>
    </select>

    <br><br>

    <button type="submit" name="update">Update</button>

</form>

<br>

<a href="tampil.php">Kembali</a>

</body>
</html>