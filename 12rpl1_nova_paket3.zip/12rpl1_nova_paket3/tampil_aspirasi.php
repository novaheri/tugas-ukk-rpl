<?php

include "koneksi.php";

$data = mysqli_query($conn, "SELECT * FROM tb_aspirasi");

if (!$data) {
    die("Query gagal: " . mysqli_error($conn));
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Aspirasi</title>
</head>
<body>

<h2>DATA ASPIRASI</h2>

<a href="tambah_aspirasi.php">+ Tambah Aspirasi</a>

<br><br>

<table border="1" cellpadding="8">

    <tr>
        <th>ID Aspirasi</th>
        <th>ID Siswa</th>
        <th>ID Kategori</th>
        <th>Isi Aspirasi</th>
        <th>Tanggal</th>
        <th>Aksi</th>
    </tr>

    <?php while ($row = mysqli_fetch_assoc($data)) { ?>

    <tr>
        <td>
            <?php echo htmlspecialchars($row['id_aspirasi']); ?>
        </td>

        <td>
            <?php echo htmlspecialchars($row['id_siswa']); ?>
        </td>

        <td>
            <?php echo htmlspecialchars($row['id_kategori']); ?>
        </td>

        <td>
            <?php echo htmlspecialchars($row['isi_aspirasi']); ?>
        </td>

        <td>
            <?php echo htmlspecialchars($row['tanggal']); ?>
        </td>

        <td>
            <a href="edit_aspirasi.php?id=<?php echo urlencode($row['id_aspirasi']); ?>">
                Edit
            </a>

            |

            <a href="hapus_aspirasi.php?id=<?php echo urlencode($row['id_aspirasi']); ?>"
               onclick="return confirm('Yakin ingin menghapus aspirasi ini?')">
                Hapus
            </a>
        </td>
    </tr>

    <?php } ?>

</table>

</body>
</html>
