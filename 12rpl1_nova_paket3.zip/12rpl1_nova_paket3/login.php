<?php
session_start();
include "koneksi.php";

if (isset($_POST['login'])) {

    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM tb_admin 
            WHERE username='$username' 
            AND password='$password'";

    $data = mysqli_query($conn, $sql);

    if (mysqli_num_rows($data) > 0) {

        $_SESSION['login'] = true;
        $_SESSION['username'] = $username;

        header("Location: dasboard.php");
        exit;

    } else {
        $pesan = "Username atau password salah!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>

<h2>LOGIN ADMIN</h2>

<?php
if (isset($pesan)) {
    echo "<p>$pesan</p>";
}
?>

<form method="POST">

    <label>Username</label><br>
    <input type="text" name="username" required>

    <br><br>

    <label>Password</label><br>
    <input type="password" name="password" required>

    <br><br>

    <button type="submit" name="login">Login</button>

</form>

</body>
</html>