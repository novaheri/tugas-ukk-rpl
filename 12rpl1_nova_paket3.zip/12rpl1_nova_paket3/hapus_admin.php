<?php
include "koneksi.php";

$id = $_GET['id'];

$query = "DELETE FROM tb_admin WHERE id_admin='$id'";

if (mysqli_query($conn, $query)) {
    header("Location: tampil_admin.php");
    exit;
} else {
    echo "Data gagal dihapus: " . mysqli_error($conn);
}
?>