<?php
include "koneksi.php";

if (isset($_POST['simpan'])) {

    $id_siswa = $_POST['id_siswa'];
    $id_kategori = $_POST['id_kategori'];
    $isi_aspirasi = $_POST['isi_aspirasi'];
    $tanggal = $_POST['tanggal'];

    $query = "INSERT INTO tb_aspirasi
              (id_siswa, id_kategori, isi_aspirasi, tanggal)
              VALUES
              ('$id_siswa', '$id_kategori', '$isi_aspirasi', '$tanggal')";

    if (mysqli_query($conn, $query)) {
        header("Location: tampil_aspirasi.php");
        exit;
    } else {
        echo "Data gagal disimpan: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Aspirasi</title>
</head>
<body>

<h2>Tambah Data Aspirasi</h2>

<form method="POST">

    ID Siswa:
    <input type="number" name="id_siswa" required>
    <br><br>

    ID Kategori:
    <input type="number" name="id_kategori" required>
    <br><br>

    Isi Aspirasi:
    <textarea name="isi_aspirasi" required></textarea>
    <br><br>

    Tanggal:
    <input type="date" name="tanggal" required>
    <br><br>

    <button type="submit" name="simpan">Simpan</button>

</form>

<br>

<a href="tampil_aspirasi.php">Kembali</a>

</body>
</html>