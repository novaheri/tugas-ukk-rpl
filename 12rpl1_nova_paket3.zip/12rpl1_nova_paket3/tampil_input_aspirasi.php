
<?php
include "koneksi.php";

$data = mysqli_query($conn, "SELECT * FROM tb_input_aspirasi");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Input Aspirasi</title>
</head>
<body>

<h2>DATA INPUT ASPIRASI</h2>

<a href="tambah_input_aspirasi.php">+ Tambah Aspirasi</a>

<br><br>

<table border="1" cellpadding="8">

    <tr>
        <th>ID</th>
        <th>ID Siswa</th>
        <th>ID Kategori</th>
        <th>Isi Aspirasi</th>
        <th>Tanggal</th>
        <th>Aksi</th>
    </tr>

    <?php while ($row = mysqli_fetch_assoc($data)) { ?>

    <tr>
        <td><?php echo $row['id_input']; ?></td>
        <td><?php echo $row['id_siswa']; ?></td>
        <td><?php echo $row['id_kategori']; ?></td>
        <td><?php echo $row['isi_aspirasi']; ?></td>
        <td><?php echo $row['tanggal']; ?></td>

        <td>
            <a href="edit_input_aspirasi.php?id_input=<?php echo $row['id_input']; ?>">
                Edit
            </a>

            |

            <a href="hapus_input_aspirasi.php?id=<?php echo $row['id_input']; ?>"
               onclick="return confirm('Yakin ingin menghapus data ini?')">
                Hapus
            </a>
        </td>
    </tr>

    <?php } ?>

</table>

</body>
</html>

