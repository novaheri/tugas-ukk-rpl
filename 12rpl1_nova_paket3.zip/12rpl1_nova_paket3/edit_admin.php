<?php
include "koneksi.php";

$id = $_GET['id'];

$data = mysqli_query($conn, "SELECT * FROM tb_admin WHERE id_admin='$id'");
$row = mysqli_fetch_assoc($data);

if (isset($_POST['update'])) {

    $nama_admin = $_POST['nama_admin'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];

    $query = "UPDATE tb_admin SET
              nama_admin='$nama_admin',
              username='$username',
              password='$password',
              email='$email'
              WHERE id_admin='$id'";

    if (mysqli_query($conn, $query)) {
        header("Location: tampil_admin.php");
        exit;
    } else {
        echo "Data gagal diubah: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Admin</title>
</head>
<body>

<h2>Edit Data Admin</h2>

<form method="POST">

    Nama Admin:
    <input type="text" name="nama_admin"
           value="<?php echo $row['nama_admin']; ?>" required>
    <br><br>

    Username:
    <input type="text" name="username"
           value="<?php echo $row['username']; ?>" required>
    <br><br>

    Password:
    <input type="password" name="password"
           value="<?php echo $row['password']; ?>" required>
    <br><br>

    Email:
    <input type="email" name="email"
           value="<?php echo $row['email']; ?>" required>
    <br><br>

    <button type="submit" name="update">Update</button>

</form>

<br>

<a href="tampil_admin.php">Kembali</a>

</body>
</html>