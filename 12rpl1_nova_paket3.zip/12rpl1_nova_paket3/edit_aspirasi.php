<?php
include "koneksi.php";

$id = $_GET['id'];

$data = mysqli_query($conn, "SELECT * FROM tb_aspirasi WHERE id_aspirasi='$id'");
$row = mysqli_fetch_assoc($data);

if (isset($_POST['update'])) {

    $id_siswa = $_POST['id_siswa'];
    $id_kategori = $_POST['id_kategori'];
    $isi_aspirasi = $_POST['isi_aspirasi'];
    $tanggal = $_POST['tanggal'];

    $query = "UPDATE tb_aspirasi SET
              id_siswa='$id_siswa',
              id_kategori='$id_kategori',
              isi_aspirasi='$isi_aspirasi',
              tanggal='$tanggal'
              WHERE id_aspirasi='$id'";

    if (mysqli_query($conn, $query)) {
        header("Location: tampil_aspirasi.php");
        exit;
    } else {
        echo "Data gagal diubah: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Aspirasi</title>
</head>
<body>

<h2>Edit Data Aspirasi</h2>

<form method="POST">

    ID Siswa:
    <input type="number" name="id_siswa"
           value="<?php echo $row['id_siswa']; ?>" required>
    <br><br>

    ID Kategori:
    <input type="number" name="id_kategori"
           value="<?php echo $row['id_kategori']; ?>" required>
    <br><br>

    Isi Aspirasi:
    <textarea name="isi_aspirasi" required><?php echo $row['isi_aspirasi']; ?></textarea>
    <br><br>

    Tanggal:
    <input type="date" name="tanggal"
           value="<?php echo $row['tanggal']; ?>" required>
    <br><br>

    <button type="submit" name="update">Update</button>

</form>

<br>

<a href="tampil_aspirasi.php">Kembali</a>

</body>
</html>