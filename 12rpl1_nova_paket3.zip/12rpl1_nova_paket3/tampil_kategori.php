<?php
include "koneksi.php";

$data = mysqli_query($conn, "SELECT * FROM tb_kategori");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Kategori</title>
</head>
<body>

<h2>DATA KATEGORI</h2>

<a href="tambah_kategori.php">+ Tambah Kategori</a>

<br><br>

<table border="1" cellpadding="8">
    <tr>
        <th>ID Kategori</th>
        <th>Nama Kategori</th>
        <th>Kode Kategori</th>
        <th>Keterangan</th>
        <th>Status</th>
        <th>Aksi</th>
    </tr>

    <?php while ($row = mysqli_fetch_assoc($data)) { ?>
    <tr>
        <td><?php echo $row['id_kategori']; ?></td>
        <td><?php echo $row['nama_kategori']; ?></td>
        <td><?php echo $row['kode_kategori']; ?></td>
        <td><?php echo $row['keterangan']; ?></td>
        <td><?php echo $row['status']; ?></td>

        <td>
            <a href="edit_kategori.php?id=<?php echo $row['id_kategori']; ?>">
                Edit
            </a>
            |
            <a href="hapus_kategori.php?id=<?php echo $row['id_kategori']; ?>"
               onclick="return confirm('Yakin ingin menghapus kategori ini?')">
                Hapus
            </a>
        </td>
    </tr>
    <?php } ?>

</table>

</body>
</html>