<?php
include "koneksi.php";

if (isset($_POST['simpan'])) {

    $nama_admin = $_POST['nama_admin'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];

    $query = "INSERT INTO tb_admin
              (nama_admin, username, password, email)
              VALUES
              ('$nama_admin', '$username', '$password', '$email')";

    if (mysqli_query($conn, $query)) {
        header("Location: tampil_admin.php");
        exit;
    } else {
        echo "Data gagal disimpan: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Admin</title>
</head>
<body>

<h2>Tambah Data Admin</h2>

<form method="POST">

    Nama Admin:
    <input type="text" name="nama_admin" required>
    <br><br>

    Username:
    <input type="text" name="username" required>
    <br><br>

    Password:
    <input type="password" name="password" required>
    <br><br>

    Email:
    <input type="email" name="email" required>
    <br><br>

    <button type="submit" name="simpan">Simpan</button>

</form>

<br>

<a href="tampil_admin.php">Kembali</a>

</body>
</html>