<?php
include "koneksi_siswa.php";

$id = (int) ($_GET['id'] ?? 0);

mysqli_query($conn, "DELETE FROM tb_siswa WHERE id_siswa=$id");

header("Location: tampil_siswa.php");
exit;
