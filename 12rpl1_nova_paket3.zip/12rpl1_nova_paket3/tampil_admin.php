<?php
include "koneksi.php";

$data = mysqli_query($conn, "SELECT * FROM tb_admin");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Admin</title>
</head>
<body>

<h2>DATA ADMIN</h2>

<a href="tambah_admin.php">+ Tambah Admin</a>

<br><br>

<table border="1" cellpadding="8">
    <tr>
        <th>ID Admin</th>
        <th>Nama Admin</th>
        <th>Username</th>
        <th>Password</th>
        <th>Email</th>
        <th>Aksi</th>
    </tr>

    <?php while ($row = mysqli_fetch_assoc($data)) { ?>
    <tr>
        <td><?php echo $row['id_admin']; ?></td>
        <td><?php echo $row['nama_admin']; ?></td>
        <td><?php echo $row['username']; ?></td>
        <td><?php echo $row['password']; ?></td>
        <td><?php echo $row['email']; ?></td>
        <td>
            <a href="edit_admin.php?id=<?php echo $row['id_admin']; ?>">
                Edit
            </a>
            |
            <a href="hapus_admin.php?id=<?php echo $row['id_admin']; ?>"
               onclick="return confirm('Yakin ingin menghapus admin ini?')">
                Hapus
            </a>
        </td>
    </tr>
    <?php } ?>

</table>

</body>
</html>