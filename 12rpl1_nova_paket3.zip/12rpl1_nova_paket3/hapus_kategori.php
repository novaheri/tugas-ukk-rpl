<?php
include "koneksi.php";

$id = $_GET['id'];

$query = "DELETE FROM tb_kategori WHERE id_kategori='$id'";

if (mysqli_query($conn, $query)) {
    header("Location: tampil_kategori.php");
    exit;
} else {
    echo "Data gagal dihapus: " . mysqli_error($conn);
}
?>