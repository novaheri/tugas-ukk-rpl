<?php
session_start();

if (!isset($_SESSION['login_siswa'])) {
    header("Location: login_siswa.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Siswa</title>
</head>
<body>

<h2>DASHBOARD SISWA</h2>

<p>
    Selamat datang,
    <?php echo $_SESSION['nama_siswa']; ?>
</p>

<p>NIS: <?php echo $_SESSION['nis']; ?></p>

<hr>

<a href="tambah_aspirasi.php">Input Aspirasi</a>
<br><br>

<a href="tampil_aspirasi.php">Data Aspirasi</a>
<br><br>

<a href="logout_siswa.php">Logout</a>

</body>
</html>