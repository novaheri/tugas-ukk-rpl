<?php
include "koneksi.php";

if (isset($_POST['simpan'])) {

    $nama_kategori = $_POST['nama_kategori'];
    $kode_kategori = $_POST['kode_kategori'];
    $keterangan = $_POST['keterangan'];
    $status = $_POST['status'];

    $query = "INSERT INTO tb_kategori
              (nama_kategori, kode_kategori, keterangan, status)
              VALUES
              ('$nama_kategori', '$kode_kategori', '$keterangan', '$status')";

    if (mysqli_query($conn, $query)) {
        header("Location: tampil_kategori.php");
        exit;
    } else {
        echo "Data gagal disimpan: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Kategori</title>
</head>
<body>

<h2>Tambah Data Kategori</h2>

<form method="POST">

    Nama Kategori:
    <input type="text" name="nama_kategori" required>
    <br><br>

    Kode Kategori:
    <input type="text" name="kode_kategori" required>
    <br><br>

    Keterangan:
    <textarea name="keterangan" required></textarea>
    <br><br>

    Status:
    <select name="status" required>
        <option value="Aktif">Aktif</option>
        <option value="Tidak Aktif">Tidak Aktif</option>
    </select>
    <br><br>

    <button type="submit" name="simpan">Simpan</button>

</form>

<br>

<a href="tampil_kategori.php">Kembali</a>

</body>
</html>